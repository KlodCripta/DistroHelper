# Copia distrohelper.sh in /usr/local/bin/
sudo cp distrohelper.sh /usr/local/bin/distrohelper
sudo chmod +x /usr/local/bin/distrohelper

echo "DistroHelper è stato installato correttamente."
