#!/bin/bash

# Dichiarazioni di stile
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
NC='\033[0m' # No Color

echo -e "${YELLOW}${BOLD}DistroHelper è sviluppato da Klod Cripta${NC}"

# Array delle descrizioni
declare -A descriptions=(
    ["Ubuntu"]="Famosissima distribuzione basata su Debian, con un'ampia comunità di supporto e una vasta gamma di software disponibili. Visita il sito: https://ubuntu.com"
    ["Fedora"]="Distribuzione orientata verso gli sviluppatori, con aggiornamenti frequenti e un ciclo di sviluppo rapido. Visita il sito: https://getfedora.org"
    ["Arch_Linux"]="Una distribuzione rolling release per utenti esperti che amano la personalizzazione e la flessibilità. Visita il sito: https://archlinux.org"
    ["Endeavour_OS"]="Basata su Arch Linux, vanta un'installazione più semplice, dei software specifici per la gestione del sistema e una maggiore stabilità. Visita il sito: https://endeavouros.com"
    ["Garuda_Linux"]="Una distribuzione rolling release che offre un'esperienza desktop pronta all'uso, ottimizzata per le prestazioni e per il gaming. Visita il sito: https://garudalinux.org"
    ["Linux_Mint"]="Distribuzione user-friendly basata su Ubuntu, con un'enfasi sulla semplicità e una vasta raccolta di software. Visita il sito: https://linuxmint.com"
    ["Debian"]="Una delle distribuzioni più antiche e stabili, con un vasto ecosistema di pacchetti software. Visita il sito: https://www.debian.org"
    ["Slackware"]="La distribuzione Linux più antica ancora in attività, apprezzata per la sua purezza e stabilità. Visita il sito: http://www.slackware.com"
    ["MX_Linux"]="Distribuzione basata su Debian con un ambiente desktop personalizzato e molte utility preinstallate. Ideale per ripristinare pc datati. Visita il sito: https://mxlinux.org"
    ["CentOS"]="Una distribuzione focalizzata sulla stabilità e la sicurezza, derivata da Red Hat Enterprise Linux. Visita il sito: https://www.centos.org"
    ["Gentoo"]="Distribuzione orientata ai power user, che consente la massima personalizzazione e ottimizzazione. Visita il sito: https://www.gentoo.org"
    ["Elementary_OS"]="Una distribuzione con un'interfaccia utente elegante e intuitiva, fortemente ispirata al design di macOS. Visita il sito: https://elementary.io"
    ["Pop_OS"]="Distribuzione pensata per il gaming e ottimizzata per gli utenti che lavorano con hardware System76, con un focus su GNOME. Visita il sito: https://pop.system76.com"
    ["Linux_Lite"]="Distribuzione leggera basata su Ubuntu, progettata per computer che iniziano a soffrire l'età. Visita il sito: https://www.linuxliteos.com"
    ["Manjaro"]="Distribuzione basata su Arch Linux con un'installazione semplificata e un'eccellente compatibilità hardware. Visita il sito: https://manjaro.org"
    ["OpenSUSE"]="Una distribuzione sponsorizzata da SUSE, con una robusta infrastruttura e strumenti di gestione avanzati. Visita il sito: https://www.opensuse.org"
    ["Solus"]="Una distribuzione indipendente con un ambiente desktop personalizzato (Budgie) e un modello di aggiornamento rolling release. Visita il sito: https://getsol.us"
    ["SUSE"]="Distribuzione orientata alle imprese con un solido supporto commerciale e un ciclo di rilascio lungo. Visita il sito: https://www.suse.com"
    ["Zorin_OS"]="Una distribuzione progettata per emulare l'aspetto e la sensazione di altri sistemi operativi, come Windows 10 o 11. Visita il sito: https://zorinos.com"
    ["Puppy_Linux"]="Distribuzione ultraleggera (32 o 64 bit) che può essere eseguita da USB o CD e caricata interamente in RAM per prestazioni rapide. Può resuscitare pc antichi. Visita il sito: https://puppylinux.com"
)

# Abilita/disabilita il debug
debug=false

# Domande del quiz
questions=(
    "${BLUE}${BOLD}1. Sei un nuovo utente di Linux?${NC}"
    "${BLUE}${BOLD}2. Preferisci una distribuzione con supporto commerciale (supporto immediato ma a pagamento)?${NC}"
    "${BLUE}${BOLD}3. Sei interessato a una distribuzione rolling release (rilascio di aggiornamenti continui e progressivi)?${NC}"
    "${BLUE}${BOLD}4. Vuoi una distribuzione basata su Debian (quindi con una forte base stabile e rodata)?${NC}"
    "${BLUE}${BOLD}5. Vuoi una distribuzione che enfatizzi la sobrietà e il minimalismo?${NC}"
    "${BLUE}${BOLD}6. Al contrario delle rolling release, preferisci una distribuzione con un ciclo di rilascio stabile e programmato (ad esempio semestrale)?${NC}"
    "${BLUE}${BOLD}7. Hai bisogno di una distribuzione molto leggera che funzioni bene su hardware meno recente se non addirittura obsoleto (pc vecchi e/o poco performanti)?${NC}"
    "${BLUE}${BOLD}8. Sei interessato a una distribuzione che offre numerosi ambienti desktop tra cui scegliere (KDE Plasma, Gnome, XFCE ecc...)?${NC}"
    "${BLUE}${BOLD}9. È indispensabile che la tua distribuzione sia facile da installare e configurare?${NC}"
    "${BLUE}${BOLD}10. Preferisci una distribuzione con un forte focus sulla personalizzazione?${NC}"
    "${BLUE}${BOLD}11. Hai esperienza con Linux e ti piace configurare il sistema da zero?${NC}"
    "${BLUE}${BOLD}12. Sei interessato a una distribuzione che sia nota per la sua stabilità e affidabilità?${NC}"
    "${BLUE}${BOLD}13. Vuoi una distribuzione che offra software sempre aggiornato all'ultima versione, anche se poco testato (con maggiore rischio di bug o instabilità)?${NC}"
    "${BLUE}${BOLD}14. È indispensabile che la distribuzione abbia una comunità di supporto molto attiva e amichevole?${NC}"
    "${BLUE}${BOLD}15. È preferibile una distribuzione con un'interfaccia utente moderna e attraente? (questo esclude di conseguenza le super-leggere).${NC}"
    "${BLUE}${BOLD}16. Vuoi una distribuzione che sia molto leggera e molto veloce anche se poco accattivante graficamente?${NC}"
    "${BLUE}${BOLD}17. Sei interessato a una distribuzione che sia adatta per server?${NC}"
    "${BLUE}${BOLD}18. Vuoi una distribuzione che sia prettamente incentrata e ottimizzata per i giochi?${NC}"
    "${BLUE}${BOLD}19. Vuoi una distribuzione che abbia un design simile a macOS?${NC}"
    "${BLUE}${BOLD}20. Preferisci una distribuzione con strumenti di configurazione grafici? (Sostanzialmente, ad uso minimo della riga di comando).${NC}"
)

# Mapping delle risposte
declare -A answer_key_mapping=(
    ["1s"]="Ubuntu Linux_Mint MX_Linux Elementary_OS Pop_OS Linux_Lite Zorin_OS Puppy_Linux"
    ["1n"]="Arch_Linux Debian Slackware Gentoo CentOS SUSE"
    ["2s"]="Ubuntu Fedora Linux_Mint OpenSUSE Zorin_OS SUSE"
    ["2n"]="Arch_Linux Debian Slackware Endeavour_OS Garuda_Linux Linux_Mint MX_Linux Gentoo Elementary_OS Pop_OS Linux_Lite Manjaro OpenSUSE Solus Zorin_OS Puppy_Linux"
    ["3s"]="Arch_Linux Endeavour_OS Garuda_Linux Manjaro"
    ["3n"]="Ubuntu Fedora Debian Slackware Mint Linux_Mint MX_Linux Elementary_OS Pop_OS Linux_Lite OpenSUSE Solus SUSE Zorin_OS Puppy_Linux CentOS Gentoo"
    ["4s"]="Ubuntu Linux_Mint MX_Linux Zorin_OS"
    ["4n"]="Arch_Linux Slackware Fedora Endeavour_OS Garuda_Linux Gentoo Elementary_OS Pop_OS Linux_Lite Manjaro OpenSUSE Solus SUSE Zorin_OS Puppy_Linux CentOS"
    ["5s"]="Arch_Linux Slackware Puppy_Linux"
    ["5n"]="Ubuntu Fedora Debian Endeavour_OS Garuda_Linux Gentoo Manjaro OpenSUSE Solus SUSE CentOS Linux_Mint MX_Linux Zorin_OS"
    ["6s"]="Ubuntu Fedora Debian Slackware Linux_Mint MX_Linux Elementary_OS Pop_OS Linux_Lite OpenSUSE Solus SUSE Zorin_OS Puppy_Linux"
    ["6n"]="Arch_Linux Slackware Endeavour_OS Garuda_Linux Gentoo Elementary_OS Pop_OS Linux_Lite Manjaro Solus SUSE Zorin_OS Puppy_Linux CentOS"
    ["7s"]="Linux_Lite Puppy_Linux"
    ["7n"]="Ubuntu Fedora Arch_Linux Endeavour_OS Garuda_Linux Gentoo Manjaro OpenSUSE Solus SUSE CentOS"
    ["8s"]="Ubuntu Fedora Arch_Linux Endeavour_OS Garuda_Linux Linux_Mint Manjaro OpenSUSE Solus"
    ["8n"]="Debian Slackware MX_Linux Elementary_OS Pop_OS SUSE Zorin_OS Puppy_Linux"
    ["9s"]="Ubuntu Linux_Mint MX_Linux Elementary_OS Pop_OS Zorin_OS"
    ["9n"]="Arch_Linux Fedora Debian Slackware Garuda_Linux Gentoo Manjaro OpenSUSE Solus SUSE Puppy_Linux CentOS"
    ["10s"]="Arch_Linux Garuda_Linux Gentoo Manjaro"
    ["10n"]="Ubuntu Fedora Debian Slackware Linux_Mint MX_Linux Elementary_OS Pop_OS OpenSUSE Solus SUSE Zorin_OS Puppy_Linux CentOS"
    ["11s"]="Arch_Linux Slackware Gentoo"
    ["11n"]="Ubuntu Fedora Debian Endeavour_OS Garuda_Linux Linux_Mint MX_Linux Elementary_OS Pop_OS Manjaro OpenSUSE Solus SUSE Zorin_OS Puppy_Linux CentOS"
    ["12s"]="Debian Slackware Gentoo CentOS"
    ["12n"]="Ubuntu Fedora Arch_Linux Endeavour_OS Garuda_Linux Linux_Mint MX_Linux Gentoo Elementary_OS Pop_OS Manjaro OpenSUSE Solus SUSE Zorin_OS Puppy_Linux CentOS"
    ["13s"]="Fedora Arch_Linux Garuda_Linux OpenSUSE Solus"
    ["13n"]="Ubuntu Debian Slackware Linux_Mint MX_Linux Elementary_OS Pop_OS SUSE Zorin_OS Puppy_Linux CentOS"
    ["14s"]="Ubuntu Fedora Linux_Mint MX_Linux Zorin_OS Puppy_Linux"
    ["14n"]="Arch_Linux Slackware Fedora Garuda_Linux Gentoo OpenSUSE Solus SUSE Puppy_Linux CentOS"
    ["15s"]="Ubuntu Garuda_Linux Linux_Mint Elementary_OS Pop_OS Zorin_OS"
    ["15n"]="Arch_Linux Slackware Fedora Debian Endeavour_OS MX_Linux Gentoo Linux_Lite Manjaro OpenSUSE Solus SUSE Puppy_Linux CentOS"
    ["16s"]="Linux_Lite Puppy_Linux"
    ["16n"]="Ubuntu Fedora Debian Arch_Linux Endeavour_OS Garuda_Linux Linux_Mint MX_Linux CentOS Gentoo Elementary_OS Manjaro OpenSUSE Solus SUSE Zorin_OS"
    ["17s"]="CentOS"
    ["17n"]="Ubuntu Fedora Arch_Linux Endeavour_OS Garuda_Linux Linux_Mint MX_Linux Gentoo Elementary_OS Pop_OS Manjaro OpenSUSE Solus SUSE Zorin_OS Puppy_Linux"
    ["18s"]="Pop_OS"
    ["18n"]="Ubuntu Fedora Debian Arch_Linux Endeavour_OS Linux_Mint MX_Linux CentOS Gentoo Elementary_OS Manjaro OpenSUSE Solus SUSE Zorin_OS Puppy_Linux"
    ["19s"]="Elementary_OS Zorin_OS"
    ["19n"]="Ubuntu Fedora Debian Arch_Linux Slackware Endeavour_OS Garuda_Linux Linux_Mint MX_Linux CentOS Gentoo Pop_OS Linux_Lite Manjaro OpenSUSE Solus SUSE Puppy_Linux"
    ["20s"]="Ubuntu Fedora Linux_Mint MX_Linux Zorin_OS Puppy_Linux"
    ["20n"]="Arch_Linux Debian Slackware Garuda_Linux Gentoo Manjaro Solus SUSE Puppy_Linux CentOS"
)

# Array per contare le distribuzioni
declare -A distros=(
    ["Ubuntu"]=0
    ["Fedora"]=0
    ["Arch_Linux"]=0
    ["Endeavour_OS"]=0
    ["Garuda_Linux"]=0
    ["Linux_Mint"]=0
    ["Debian"]=0
    ["Slackware"]=0
    ["MX_Linux"]=0
    ["CentOS"]=0
    ["Gentoo"]=0
    ["Elementary_OS"]=0
    ["Pop_OS"]=0
    ["Linux_Lite"]=0
    ["Manjaro"]=0
    ["OpenSUSE"]=0
    ["Solus"]=0
    ["SUSE"]=0
    ["Zorin_OS"]=0
    ["Puppy_Linux"]=0
)

# Inizia il quiz
echo -e "${RED}${BOLD}Inizia il quiz per determinare la distribuzione Linux più adatta a te.${NC}"

for (( i=0; i<${#questions[@]}; i++ )); do
    echo -e "${questions[$i]}"
    echo -e "${GREEN}${BOLD}S) Sì${NC}"
    echo -e "${GREEN}${BOLD}N) No${NC}"
    read -p "Inserisci la tua risposta (S o N): " answer
    answer=${answer,,} # converti in minuscolo

    if [[ $answer == "s" || $answer == "n" ]]; then
        index=$((i + 1))
        key="${index}${answer}"
        for distro in ${answer_key_mapping[$key]}; do
            ((distros[$distro]++))
        done
    else
        echo "Risposta non valida. Inserisci S per Sì o N per No."
        ((i--)) # torna alla domanda precedente
    fi
done

max_count=0
max_distro=""

for distro in "${!distros[@]}"; do
    if [[ ${distros[$distro]} -gt $max_count ]]; then
        max_count=${distros[$distro]}
        max_distro=$distro
    fi
done

# Stampa la distribuzione Linux consigliata
echo -e "${RED}${BOLD}La distribuzione Linux consigliata per te è: ${max_distro}${NC}"
echo -e "${YELLOW}${BOLD}${descriptions[$max_distro]}${NC}"

# Aggiungi questa linea per mantenere il terminale aperto
read -p "Premi invio per chiudere il terminale"
